<div class="header">
<a href="http://localhost/chat.ty/index.php/user/registration" style=" float:right; text-decoration:none; margin-right:110px; color:#FFFFFF; font-weight:bold;">Sign up</a>
<a href="http://localhost/chat.ty/main/" style=" float:right; text-decoration:none; margin-right:10px; color:#FFFFFF; font-weight:bold;">Login</a>



</div>

<style>
body{
width:80%;
height:75%;
border:1px solid #000000;
}
.header{
width:100%;
height:35px;
margin-left:0px;
background: #990000;
text-decoration:none;
}
</style>